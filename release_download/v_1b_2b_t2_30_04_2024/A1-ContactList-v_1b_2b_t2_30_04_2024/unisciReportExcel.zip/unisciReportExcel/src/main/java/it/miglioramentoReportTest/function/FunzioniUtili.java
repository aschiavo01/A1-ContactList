package it.miglioramentoReportTest.function;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import it.miglioramentoReportTest.model.ReportTest;
import it.miglioramentoReportTest.model.TabellaReport;

public class FunzioniUtili {

	// definiamo la stringa in cui effettuare la ricerca
    // e la sottostringa da ricercare
    
	public FunzioniUtili() {
		super();
	}
	
	
	
	public int cercaSottoStringa(String stringa, String sottostringa){
	
    int indiceMatching = 0; //indice al quale inizia la sottostringa cercata

    // al momento non è stata effettuata alcuna ricerca
    // ne conseguito alcun risultato 		
    Boolean cerca = false;

    // calcoliamo lunghezza di stringa e sottostringa
    // la differenza sarà condizione di terminazione per il ciclo for
    int max = (stringa.length() - sottostringa.length());

    // ricerchiamo la sottostringa ciclando il contenuto di quest'ultima
    test:
    for (int i = 0; i <= max; i++) {
      int n = sottostringa.length();
      int j = i;
      int k = 0;
      while (n-- != 0) {
        if (stringa.charAt(j++) != sottostringa.charAt(k++)) {
          continue test;
        }
      }

      // a questo punto è stata effettuata una ricerca
      // sarà possibile produrre un output			
      cerca = true;
      indiceMatching = i; //indice in cui avviene il matching
      break test;
    }

    // stampiamo l'output sulla base dell'esito della ricerca		
    System.out.println(cerca ? "Tovata" : "Non Trovata");
	
    if(cerca==true) {
    	
    	System.out.println("La sottostringa cercata inizia all'indice: "+indiceMatching);
    	
    }else {
    	indiceMatching = -1;
    }
    
    
    return indiceMatching;
	
	}

	
	public LinkedList<File> findAllFilesInFolder(File folder, String estensioneFile) {
		LinkedList<File> listaFile = new LinkedList<File>();
		
		for (File file : folder.listFiles()) {
			if (!file.isDirectory()) {
				System.out.println(file.getName());
				if(file.getName().endsWith("."+estensioneFile)) {
				listaFile.add(file);
				}
			} else {
				findAllFilesInFolder(file,estensioneFile);
			}
		}
		return listaFile;
	}
	
	
	
	public void creaFileExcel(TabellaReport tabella, String fileDaCreare) {
		
			
		
		try {
            String filename = fileDaCreare+".xls";
            HSSFWorkbook workbook = new HSSFWorkbook();
            HSSFSheet sheet = workbook.createSheet("FirstSheet");  

            HSSFRow rowhead = sheet.createRow((short)0);
            rowhead.createCell(0).setCellValue("TEST SUITE");
            rowhead.createCell(1).setCellValue("TEST CASE");
            rowhead.createCell(2).setCellValue("RELEASE DI CREAZIONE");
            rowhead.createCell(3).setCellValue("LOCATORE");
            rowhead.createCell(4).setCellValue("ESITO TEST");
            rowhead.createCell(5).setCellValue("MESSAGGIO ESITO TEST");
            rowhead.createCell(6).setCellValue("CAUSA ROTTURA TEST");
            
            //Iterare ogni riga per ogni elemento della tabella
            LinkedList<ReportTest> lista = tabella.getListaReport();
            int numero_istanza = 1;
            for(ReportTest r: lista) {
            HSSFRow row = sheet.createRow((short)numero_istanza);
            row.createCell(0).setCellValue(r.getNomeTestSuite());
            row.createCell(1).setCellValue(r.getNomeTest());
            row.createCell(2).setCellValue(r.getReleaseDiCreazione());
            row.createCell(3).setCellValue(r.getLocatoreUtilizzato());
            row.createCell(4).setCellValue(r.getEsitoTest());
            row.createCell(5).setCellValue(r.getMsgEsitoTest());
            row.createCell(6).setCellValue(r.getCausaRotturaTest());
            
            numero_istanza++;
            }

            FileOutputStream fileOut = new FileOutputStream(filename);
            workbook.write(fileOut);
            fileOut.close();
            workbook.close();
            System.out.println("Your excel file has been generated!");

        } catch ( Exception ex ) {
            System.out.println(ex);
        }
		
		
		
		
	}
	
}
